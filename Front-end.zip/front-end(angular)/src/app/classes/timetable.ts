export class Timetable {

    timetableId!: number;
    stream!: string;
    batch!: string;
    name!: string;
}
