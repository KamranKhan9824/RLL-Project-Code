export class Library {
    lusername!: string;
    lpassword!: string;
}
