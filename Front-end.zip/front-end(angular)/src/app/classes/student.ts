export class Student {
    susername!: string;
    spassword!: string;
    name!:string;
	contact_no!:string;
	stream!:string;
	batch!:string;
	parent_details!:string;
}
