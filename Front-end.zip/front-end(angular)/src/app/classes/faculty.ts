export class Faculty {
  fusername!: string;
  fpassword!: string;
  map: any;
}
