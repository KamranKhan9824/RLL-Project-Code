// this is the class of admin
export class Admin {
    ausername!: string;
    apassword!: string;
}
