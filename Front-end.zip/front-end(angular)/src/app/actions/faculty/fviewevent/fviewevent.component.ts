import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fviewevent',
  templateUrl: './fviewevent.component.html',
  styleUrls: ['./fviewevent.component.css']
})
export class FvieweventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
