import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fattendance',
  templateUrl: './fattendance.component.html',
  styleUrls: ['./fattendance.component.css']
})
export class FattendanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
