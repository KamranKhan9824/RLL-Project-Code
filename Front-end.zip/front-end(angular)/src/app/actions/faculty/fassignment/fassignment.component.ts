import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fassignment',
  templateUrl: './fassignment.component.html',
  styleUrls: ['./fassignment.component.css']
})
export class FassignmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
