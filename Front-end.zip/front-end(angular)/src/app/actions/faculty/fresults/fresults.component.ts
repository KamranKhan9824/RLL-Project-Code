import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fresults',
  templateUrl: './fresults.component.html',
  styleUrls: ['./fresults.component.css']
})
export class FresultsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
